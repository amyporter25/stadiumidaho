Stadium Idaho — files for a 3D modeler (Whitestone + Brownstone GLBs)

What to build: three web .glb files. Full spec in 00-brief.md.

PDFs
  whitestone-7-2-rwr.pdf          Whitestone front-entry construction set
  whitestone-29-3-pse.pdf         Whitestone side-entry construction set
  brownstone-15-2-rwr.pdf         Brownstone construction set

Elevations / cutouts
  whitestone-front.png            ArchyBase / marketing front
  whitestone-rear.png             ArchyBase / marketing rear
  brownstone.png                  Brownstone photoreal cutout

Floor plans
  whitestone-front-floorplan.jpg
  whitestone-side-floorplan.jpg
  brownstone-floorplan.jpg
