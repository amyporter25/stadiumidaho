Stadium Idaho — reference pack for a 3D modeler

This zip is PDFs, photos, and a spec only.
It does NOT include app source code, Blender scripts, or any existing .glb files.

See 00-brief.md for what to build.
