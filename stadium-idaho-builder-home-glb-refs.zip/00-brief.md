# Stadium Idaho — builder home GLB brief

**Project:** The Stadium (north Caldwell, Idaho) — lot visualizer for home buyers  
**Deliverable:** One web-optimized `.glb` per plan below.

Do **not** model from a photo glued onto a box, a PDF extrusion, or a silhouette cutout. The house must look like the marketed exterior when the camera orbits to the sides and rear.

---

## Plans (priority order)

| Priority | Plan | Garage layout | Reference PDF |
|----------|------|---------------|---------------|
| 1 | The Whitestone — front | Tall RV + two-car, both street-facing (street-view **left**) | `whitestone-7-2-rwr.pdf` |
| 2 | The Whitestone — side | Side-entry two-car + front-facing RV bay | `whitestone-29-3-pse.pdf` |
| 3 | The Brownstone | Front-facing garage + RV bay | `brownstone-15-2-rwr.pdf` |

Also in this folder: front/rear elevations, a Brownstone cutout, and floor-plan images.

---

## Technical requirements

1. **Format:** glTF 2.0 binary (`.glb`)
2. **Units:** meters
3. **Origin:** ground plane, center of the building footprint
4. **Orientation:** street facade faces **−Z** (right-handed Y-up, same as three.js)
5. **Scale:** Whitestone front ≈ 94′ × 58′; Whitestone side ≈ 94′ × 78′; Brownstone ≈ 91′ × 72′
6. **Web budget:** about 50k–150k triangles; optimized textures; **under ~15–25 MB** per file
7. **Materials:** PBR — siding, roof, glass, trim, garage doors as separate materials
8. **No** cameras, lights, interiors, furniture, cars, or landscaping

### Driveway attach points (required)

Empty nodes (or well-named objects) at the **center of the vehicle door threshold, at ground (Y = 0)**:

| Node name | When |
|-----------|------|
| `GarageDoorFront` | Street-facing garage. If RV + two-car both face the street, use the midpoint. |
| `GarageDoorSide` | Side-entry two-car doors only (Whitestone side plan). |

---

## Visual requirements

- Match the ArchyBase / marketing exterior: Whitestone is white board-and-batten, dark gabled roofs, timber entry.
- Garage wing on the **correct side** (Whitestone: street-view **left**).
- Orbit must still read as that house (sides and rear modeled, not blank).

---

## Delivery checklist (each plan)

- [ ] `whitestone-front.glb` / `whitestone-side.glb` / `brownstone.glb`
- [ ] Screenshots: street front, ¾ orbit, rear
- [ ] Note: footprint, triangle count, texture sizes, node list
- [ ] Confirm `GarageDoorFront` / `GarageDoorSide` as applicable

## Acceptance

Dropped into a browser three.js scene: street view looks like the builder home; orbit still looks like a house; driveway can attach to the named garage nodes.
